===============================================================================
Important points and problem encountered during the developpement of this tool
===============================================================================
- WIDGETS:
Must create a method (in class Window) to get every widgets.
Destroy them after if it's necessary.
ex: ./screenshots/getWidgets.png

- IMAGES:
Must be integrated with an attributes of the class.
Else it doesn't display the color.
ex: ./screenshots/imgAtt.png

- ATTRIBUTES:
Can not generate a string and make it as an attributes.
The attributes must be defined in a list at least.
ex (which are not working): ./screenshots/strToAtt.png

Method call with arguments (in the class) are executed automaticely.
Must save every data need in an attribute.
ex: ./screenshots/argument.png

Instanciation of an object and the method pack() must be called in 2 separate lines
if the object is an attribute. The contrary create an error (do not exist) when we
want to use this object.
ex: ./screenshots/pack.png

- TABLE:
The length of a list is not equals to index maximum of the list.
because index start from 0 and length start from 1.
