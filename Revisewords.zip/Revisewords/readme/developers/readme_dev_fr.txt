================================================================================
Points importants et problèmes rencontrés pendant le développement de cet outil
================================================================================
- ELEMENTS GRAPHIQUES:
Il faut créer une méthode (dans la classe Window) pour récupérer les éléments
graphiques de la page. Les détruire après si nécessaire
ex: ./screenshots/getWidgets.png

- IMAGES:
Elles doivent être associées à un attribut de la classe.
Sinon les couleurs ne sont pas affichées
ex: ./screenshots/imgAtt.png

- ATTRIBUTS:
Ne peut pas générer une chaine de caractère et l'attribuer à un attribut.
L'attribut doit être définit dans une liste au préalable.
ex (ne fonctionne pas): ./screenshots/strToAtt.png

Une méthode appelée avec des arguments en paramètres est exécuter automatiquement.
Les données utiles doivent être stockées dans un attribut de la classe.
ex: ./screenshots/argument.png

L'instanciation d'un objet et la méthode pack() doit être appelées sur 2 lignes
séparées si l'objet est un attribut. Le contraire provoque une erreur (n'existe pas)
lorsque l'on souhaite utiliser cet objet.
ex: ./screenshots/pack.png

- TABLE:
La longueur d'une liste n'est pas égale à l'indice maximum de la liste.
car l'indice commence à 0 et la longeur commence à 1.

La hauteur de la fenêtre donnée par la méthode winfo_height() prend en compte la barre blanche (avec le titre) par défaut mais pas le menu rajouté après (24px par défaut)