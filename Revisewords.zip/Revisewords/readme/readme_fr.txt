===============================================================================
Quel est l'objectif de ce projet ?
- Il a été créé pour aider les étudiants a réviser leur vocabulaire dans des
conditions proches de l'école
===============================================================================
Comment l'utiliser ?
- Mettez le fichier (au format .csv) qui contient les mots de vocabulaire dans
le dossier "vocabulary"
- Executez le programme: "nom du programme"
- Suivez les instructions
- Travaillez autant que vous le souhaitez
===============================================================================
Comment puis-je récupérer un fichier .csv ?
- Tout d'abord, créer un tableau de 2 colonnes
- Téléchargez le si il est sur votre drive
- Ouvrez un éditeur de texte comme "LibreOffice", "OpenOffice",
"Microsoft Word"
- Sauvegardez le fichier dans le dossier "vocabulaire" tout en faisant attention
à choisir la bonne extension de fichier
- Allez en bas de la fenêtre, il y a une barre et parcourez la jusqu'à ce que
vous voyez le format souhaité
###############################################################################
AIDE:
Demandez au créateur si vous avez besoin d'une précision quelconque

PROPOSITIONS:
Si vous avez une quelconque proposition, idée pour améliorer cet outil
contactez le créateur
###############################################################################
Si vous avez vu une erreur, un problème, s'il vous plaît contactez le créateur
et il résolvera le problème le plus vite possible
