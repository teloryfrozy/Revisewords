===============================================================================
What's the goal of this project ?
- It was created to help students to learn their vocabulary
in near school conditions
===============================================================================
How to use it ?
- Put the file (in .csv format) containing the vocabulary words
in the "vocabulary" directory
- Execute the program: NAME OF THE program
- Follow the instructions
- Work as many as you want
===============================================================================
How to get a .csv file ?
- First of all, create a table of 2 columns
(Language where you want to progress, Language you know)
- Download it if it's on your drive
- Open a text reader app like "LibreOffice", "OpenOffice", "Microsoft Word"
- Save the file on "vocabulary" folder while paying attention to choose the
good extension of file (.csv)
- Go at the bottom of the window, there is a bar and scroll until you see
the aimed format
###############################################################################
HELP:
Ask the creator, if you need any kind of precision

PROPOSITIONS:
- If you have any kind of proposition, or idea to make better this little tool
contact the creator
###############################################################################
If you saw a mistakes, problem or translation error please contact the
creator and he will fix it as soon as possible
