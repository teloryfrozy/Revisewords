"""
Possible optimization and improvement:
- Minimise repetitions:
    - One method to get an info from a dictionnary with *args
"""
from json import dump, load

# Constants
FOLDER = "program/settings/" # root settings folder
PARAM = "program/settings/param.json" # parameters file
LANG = "program/settings/lang/" # languages files

def setParam(param, value):
    """Changes the value of a parameter and saves it in the settings file.
    
    Parameters:
        - (str) param: parameter 
        - (str) value: value of the parameter
    """
    data = getData(PARAM)
    data[param] = value
    with open(PARAM, "w") as f:
        dump(data, f, indent=4) # saves the modifications

def getData(path):
    """Returns the data of a settings file.
    
    Parameter:
        - (str) path: path to the file
    """
    with open(path) as f:
        return load(f)

def getParam(param):
    """Returns the value of a parameter.
    
    Parameter:
        - (str) param: parameter
    """
    return getData(PARAM)[param]

def getGroundColor(ground):
    """Returns the color of ground.
    
    Parameter:
        - (str) ground: "fg" or "bg"
    """
    return getData(FOLDER + "themes/attributes.json")[getParam("theme")][ground]

def getLang():
    """Returns the language's data sets in the settings."""
    return getData(LANG + getParam("language") + ".json")

def getText(section):
    """Returns text from section."""
    return getLang()[section]

def getHomeT(section):
    """Returns the text of the home page."""
    return getLang()["sections"][section]
