# If this file exists, it means that you have not launched the tool yet. This file is self-destructing.
from os import system, remove, path, chdir, rmdir
from pkg_resources import working_set
from shutil import move, rmtree

def installModules():
    """Checks for missing packages. Installs the missing modules required by the software. Self-destructs."""
    required = {"pyinstaller", "pillow", "pyautogui", "pandas"} # modules required
    installed = {pkg.key for pkg in working_set} # modules already installed
    missing = required - installed # missing modules that are not installed yet

    for module in missing: # if there is missing modules
        system('pip install ' + module) # Installs them
    remove(path.dirname(__file__) + '/init.py') # deletes this file

def createMain():
    """Create the main file. Converts it into an executable file."""
    with open(path.dirname(__file__) + '\main.py', 'w') as f: # opens the file with an alias
        f.write('''\
from classes.window import Window\n
Window()
''')
    chdir(path.dirname(__file__)) # changes the default path to the current working directory
    system('pyinstaller --onefile -w main.py') # converts the python file into an executable application
    move('dist/main.exe', "../main.exe") # gets (exe) main and moves it to the root folder
    # Deletes useless files and folders:
    rmdir('dist') # deletes (directory) dist
    rmtree('build') # deletes (directory) build
    remove('main.spec') # deletes (file) main.spec
    remove('main.py') # deletes (file) main.py

installModules()
createMain()
