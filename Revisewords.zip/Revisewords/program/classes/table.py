"""
Possible optimizations and improvements:
- setWords return a message if there is less than 20 words (+1 with headers) in the list
"""

import csv
from random import randint

class Table:
    """Class to generate a list of vocabulary with a csv file."""
      
    def __init__(self):
        """An array is defined by a list.

        Attributes:
            - (list) table: list of words, default empty
        """
        self.table = [] # vocabulary array of tuples of 2 elements
    
    def setTable(self, file):
        """Log in a list all the data came from the file.

        Parameter:
            - (str) file: file name

        Method:
            Browse the list
            On every new entry add it on a list: self.table
            Add it on an attribute of the class
        """
        # Loop to log any vocabulary word:
        with open(file, newline="", encoding="utf-8") as csvfile:
            entries = csv.reader(csvfile, delimiter=",")
            for line in entries: # line: one entry, entries: every entry
                self.table.append(line) 

    def setWords(self):
        """Sort 20 randoms words in 2 category: (list) words: words untranslated, (list) translation: translation of the words.
               
        Method:
            Repeat it 20 times
                Generate a random number between 0 to len(table)
                Add the word and its translation in (list) words and (list) translation
                Remove it from the array: (list) table
        """
        self.words = []
        self.translation = []
        self.points = []
        for i in range(20):
            r = randint(1, len(self.table)-1) # 1 (0 => headers, not words), -1 refer to: "readme_dev_en.txt"
            self.words.append(self.table[r][0])
            self.translation.append(self.table[r][1])
            self.points.append(self.table[r][2])
            self.table.pop(r)

    def getMaxWidth(self, table):
        """Returns the lenght of the word that has the max lenght in a list.

        Method:
            maxWidth: lenght first element
            Browses the list
                If length of the next words is greater than maxWidth
                    Change value maxWidth
        """
        maxWidth = len(table[0])
        for i in range(1, len(table)):
            if len(table[i]) > maxWidth:
                maxWidth = len(table[i])
        return maxWidth
