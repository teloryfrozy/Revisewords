"""
Possible optimizations and improvements:
- Auto update text of current page when language is changed
- Auto update size of widgets when 'maximize' or 'minimize' is pressed
- Minimise code:
    - Reduce the number of variables and attributes
    - Button that changes according to the current value
        - 'setDark' and 'setLight' => Button that can have 2 values that does not show current mode
        - Menu that contains the available languages => Menu that does not show the language used
- Exercise - "section"
    - prevent when there is less than 20 words in a file => can't use it
        - Display the words even if there are less than 20 => not a full array
        - Use the other file (kn) to complete the missing words but must display the "unknown" words
- Words correction
    - Do not accept answers even if they are right (translation.csv)
        When there are special characters => False even if it is right
- Print
    - Be able to print correctly even though the window is not centered
- Link F11 to set the screen in fullscreen
"""
# [Copyright Free]
# Author: Telory Frozy

from tkinter import E, W, Button, Entry, Frame, Label, Menu, PhotoImage, Tk, messagebox, ttk, StringVar, NE, RIDGE
from classes.table import Table
from classes.tooltip import CreateToolTip
from os import listdir, remove, startfile
from PIL import Image
from time import sleep
from pyautogui import screenshot
import parameters
import csv
import pandas

class Window:
    """Class to generate a window already configured."""

    def __init__(self):
        """Create a window. By default create the home page of the tool.
        
        Attributes:
            - w (Tk): instance of tkinter
            - wHeight (int): height of the window
            - wWidth (int): width of the window
        """
        self.w = Tk()
        self.w.iconbitmap("program/decoration/images/translator.ico") # icone of the tool
        self.w.title("Revisewords")
        self.resize() # fullscreen by default
        self.w.minsize(int(0.6*self.w.winfo_screenwidth()), int(0.85*self.w.winfo_screenheight()))
        self.home() # sets home
        self.w.mainloop() # displays to home page

    def home(self):
        """Create the GUI: graphic user interface for home page whiches already configured."""
        self.clear() # refreshes the window
        h = self.w.winfo_height() # height of the screen
        self.imgQ = PhotoImage(file="program/decoration/buttons/close.png") # quit image
        self.qB = Button(self.w, image=self.imgQ, cursor="hand2", command=self.w.quit, borderwidth=1) # quit button
        self.qB.place(relx=1, anchor=NE) # relative position
        self.homeFrame = Frame(self.w)
        Label(self.homeFrame, text=parameters.getHomeT("home")["languages"], font=("Arial", int(2/53*h))).pack(pady=int(3/106*h)) # section name
        # Vocabulary
        Label(self.homeFrame, text=parameters.getHomeT("home")["vocabulary"], font=("Arial", int(5/212*h))).pack(pady=int(1/53*h))
        self.fNv = StringVar(); self.fNv.set(parameters.getHomeT("home")["file"]) # (StringVar) fNv: file name vocabulary
        fList = ttk.Combobox(self.homeFrame, textvariable=self.fNv, state="readonly", font=("Arial", int(1/53*h))) # list of selectables files
        fList["values"] = listdir("program/ressources/vocabulary") # sets options as every file in (directory) "vocabulary"
        fList.pack(pady=int(1/106*h))
        self.imgGB = PhotoImage(file="program/decoration/buttons/generate/" + parameters.getParam("language") + ".png") # image Generator button
        b = Button(self.homeFrame, image=self.imgGB, cursor="hand2", borderwidth=0, command=lambda:self.setSection(self.fNv.get(), "vocabulary"))
        b.pack(pady=int(1/106*h))
        CreateToolTip(b, parameters.getHomeT("vocabulary")["bubble"])
        # Expressions
        Label(self.homeFrame, text=parameters.getHomeT("home")["expressions"], font=("Arial", int(5/212*h))).pack(pady=int(1/53*h))
        self.fNe = StringVar(); self.fNe.set(parameters.getHomeT("home")["file"])
        fList = ttk.Combobox(self.homeFrame, textvariable=self.fNe, state="readonly", font=("Arial", int(1/53*h))) # list of selectables files
        fList["values"] = listdir("program/ressources/expressions")
        fList.pack(pady=int(1/106*h))
        b = Button(self.homeFrame, image=self.imgGB, cursor="hand2", borderwidth=0, command=lambda:self.setSection(self.fNe.get(), "expressions"))
        b.pack(pady=int(1/106*h))
        CreateToolTip(b, parameters.getHomeT("expressions")["bubble"])
        self.setLang(parameters.getParam("language"))
        self.homeFrame.pack(pady=int(1/53*h))
        # Frames used to place flags
        leftFrame = Frame(self.w) # frames are used to be placed on sides of the window
        rightFrame = Frame(self.w)
        # Resize images if necessary
        size = [self.w.winfo_screenwidth(), self.w.winfo_screenheight()] # size of the screen
        paramSize = parameters.getParam("screenSize")
        if paramSize == [None, None] or size != paramSize:
            parameters.setParam("screenSize", size) # saves the real size of the screen
            self.resizeImgs()
        # Decorations Flags
        # Logs the images in the memory
        p = "program/decoration/images/"
        self.f0 = PhotoImage(file=p+"uk_flag.png")
        self.f1 = PhotoImage(file=p+"us_flag.png")
        self.f2 = PhotoImage(file=p+"fr_flag.png")
        self.f3 = PhotoImage(file=p+"de_flag.png")
        fL = [self.f0, self.f1, self.f2, self.f3] # (list) fL: flag list
        # Flags placement
        for i in range(4):
            if i > 1:
                Label(rightFrame, image=fL[i]).pack(pady=0.05*h)
            else:
                Label(leftFrame, image=fL[i]).pack(pady=0.05*h)
        leftFrame.place(rely=0.5, anchor=W)
        rightFrame.place(rely=0.5, relx=1, anchor=E)
        self.setTheme() # apply the theme

    def setSection(self, fName, section):
        """Gets the file selected by the user in the section. Create a page of 20 random words displayed in a table.
        
        Parameter:
            - (str) fName: file name
            - (str) section : review section (ex : vocabulary, expressions)

        Method:
            If no file is selected: prevent the user and stop the method
            Else: Create the page with a table of vocabulary
        """
        # Important: file has to have 3 columns
        if fName not in listdir("program/ressources/" + section): # tests if a file has been selected
            return self.invalidFile()
        self.fN = fName  # file name
        self.fP = "program/ressources/" + section + "/" # file path
        # Create the known file if it does not exists
        if fName[:-7] + "_kn.csv" not in listdir("program/ressources/" + section):
            with open(self.fP + fName) as f:
                for x in csv.reader(f, delimiter=','):
                    headers = [x]
                    break # only one execution
            with open(self.fP + fName[:-4] + "_kn.csv", "w", newline='') as f:
                # Add the headers on the known file
                csv.writer(f, delimiter=',').writerows(headers)
        self.clear() # refreshes the window     
        h = self.w.winfo_height() # height of the screen
        hl = int(21/1060*h)
        self.title = Label(self.w, text=parameters.getHomeT("vocabulary")["goal"], font=("Arial", int(27/1060*h))) # goal of the user
        self.title.pack(pady=int(5/212*h)) # adds it to the window
        randomTable = Table()
        randomTable.setTable("program/ressources/" + section + "/" + fName)
        randomTable.setWords()
        self.wrd = randomTable.words # saves the words with an attribute
        self.trs = randomTable.translation # saves the data of randomTable to compare it with user's inputs
        self.pts = randomTable.points # saves the points of words with an attribute
        self.section = Frame(self.w) # frame which content the words, puts in and tidy up in columns and rows
        # Sets the headers
        Label(self.section, text=randomTable.table[0][0], font=("Arial", hl, "underline")).grid(row=0, column=0)
        Label(self.section, text=randomTable.table[0][1], font=("Arial", hl, "underline")).grid(row=0, column=1)
        # Displays the words in a table:
        for r in range(20):
            for c in range(2):
                if c == 1:
                    # row0: Labels => +1 for the next rows
                    Entry(self.section, width=randomTable.getMaxWidth(randomTable.translation), font=("Arial", hl)).grid(row=r+1, column=c)
                else:
                    # row0: Labels => +1 for the next rows
                    Label(self.section, text=randomTable.words[r], font=("Arial", hl)).grid(row=r+1, column=c)
        self.section.configure(borderwidth=3, relief=RIDGE); self.section.pack() # displays the table
        self.checkI = PhotoImage(file="program/decoration/buttons/check/"  + parameters.getParam("language") + ".png") # check button
        self.checkB = Button(self.w, image=self.checkI, cursor="hand2", borderwidth=0, command=lambda:self.check(self.getAnswers(self.section),
                            self.section, lambda:self.setSection(fName, section)))
        self.checkB.pack(pady=int(1/106*h))
        self.setTheme()

    def check(self, asw, frame, method):
        """Verify the user's answers with the correct. Give a score /20. Display the great answers.
        
        Parameters:
            - (list) asw: list of the user's answers
            - (Frame) frame: frame where are widgets
            - (function) method: method to reset the exercise
        
        Method:
            If answer is right
                If file is not known <=> contains "unknown words"
                    If word's points = 1
                        Cut and Paste it in the kn file
                    Else
                        word's points = 1
                Else <=> file contains "known words"
                    word's points = 3
            Else <=> answer is wrong
                If file is known
                    If word's points = 1
                        Cut and Paste it in the "unknown" file
                    Else
                        word's points -= 1
        """
        kn = True # bool: known file or not
        file = self.fP + self.fN
        if self.fN[len(self.fN)-7:-4] != "_kn":
            kn = False
        score = 0 # initializes the score
        hl = int(21/1060*self.w.winfo_height())
        for i in range(20):
            # Answer is right
            if asw[i].lower() == self.trs[i].lower(): # ignores case while comparing
                score += 1 # increases the score
                Label(frame, text=self.trs[i], font=("Arial", hl), fg="green",
                    background=parameters.getGroundColor("bg")).grid(row=i+1, column=2)
                if not kn: # file does not end with "_kn"
                    if self.pts[i] == "1":
                        # Delete the word from the other file                        
                        with open(file) as f:
                            for x in csv.reader(f, delimiter=','):
                                headers = [x]
                                break # only one execution
                        df = pandas.read_csv(file)
                        df = df[eval("df.{}".format(headers[0][0])) != self.wrd[i]] # deletes row
                        df.to_csv(file, index=False)
                        # Write the word in the kn file
                        with open(file[:-4] + "_kn.csv", "a", newline='') as f:
                            csv.writer(f, delimiter=',').writerows([[self.wrd[i], self.trs[i], "3"]])
                    else:
                        # Modify the file and give 1 point for the word
                        with open(file, "r") as f:
                            content = csv.reader(f)
                            l = list(content) # other list to avoid problems while comparing
                            for x in l:
                                if x[0] == self.wrd[i]:
                                    df = pandas.read_csv(file)
                                    # update value, -1: do not care about headers
                                    df.loc[l.index(x)-1, "points"] = "1"
                                    df.to_csv(file, index=False) # save the changes
                                    break
                else: # file end with "_kn"
                    # Modify the file and give 3 points for the word
                    with open(file, "r") as f:
                        content = csv.reader(f)
                        l = list(content) # other list to avoid problems while comparing
                        for x in l:
                            if x[0] == self.wrd[i]:
                                df = pandas.read_csv(file)
                                df.loc[l.index(x)-1, "points"] = "3"
                                df.to_csv(file, index=False) # save the changes
                                break
            # Answer is wrong
            else:
                Label(frame, text=self.trs[i], font=("Arial", hl), fg="red",
                    background=parameters.getGroundColor("bg")).grid(row=i+1, column=2)
                if kn:                    
                    if self.pts[i] == "1":
                        # Cut and Paste the word in the "unknown" file
                        # Delete the word from the other file                        
                        with open(file) as f:
                            for x in csv.reader(f, delimiter=','):
                                headers = [x]
                                break # only one execution
                        df = pandas.read_csv(file)
                        df = df[eval("df.{}".format(headers[0][0])) != self.wrd[i]] # deletes row
                        df.to_csv(file, index=False)
                        # Write the word in the "unknown" file
                        with open(file[:-7] + ".csv", "a", newline='') as f:
                            csv.writer(f, delimiter=',').writerows([[self.wrd[i], self.trs[i], "0"]])
                    else:
                        # Modify the file: word's points: -1
                        with open(file, "r") as f:
                            content = csv.reader(f)
                            l = list(content) # other list to avoid problems while comparing
                            for x in l:
                                if x[0] == self.wrd[i]:
                                    df = pandas.read_csv(file)
                                    df.loc[l.index(x)-1, "points"] = int(self.pts[i])-1
                                    df.to_csv(file, index=False) # save the changes
                                    break
        # Stuff to naviguate in the application
        self.title.configure(text=parameters.getHomeT("vocabulary")["score"].format(score)) # displays the score
        self.rI = PhotoImage(file="program/decoration/buttons/reload.png") # reload image        
        Label(frame, text=parameters.getHomeT("vocabulary")["answers"], font=("Arial", hl, "underline"),
            fg=parameters.getGroundColor("fg"), background=parameters.getGroundColor("bg")).grid(row=0, column=2) # answers: column index 2
        self.checkB.configure(image=self.rI, command=method) # reload button

    def clear(self):
        """Deletes all widgets except the quit button and the menu."""
        l = self.w.place_slaves() + self.w.slaves() # list of the widgets of the window
        for w in l:
            if w != self.qB: # exept the quit button
                w.destroy() # destroys them

    def setTheme(self, theme=None):
        """Apply the theme to the window. Saves the new theme if it has been changed.
        
        Parameter:
            - (str) theme: theme changed, by default None
        """
        if theme:
            parameters.setParam("theme", theme) # saves in param
        fg, bg = parameters.getGroundColor("fg"), parameters.getGroundColor("bg")
        self.w.config(background=bg) # sets the background
        # list of every widgets on the window
        l = self.w.place_slaves() + self.w.slaves()
        for w in l:
            if w.winfo_class() == "Frame":
                l += w.pack_slaves() + w.grid_slaves() + w.slaves()
        for w in l:
            try:
                w.config(background=bg) # images background
                w.configure(fg=fg) # text color
                w.configure(activebackground=bg) # buttons background
            except: pass # Already done
        
    def setLang(self, lang):
        """Sets the toolbar with the selected language."""
        parameters.setParam("language", lang)
        toolbarT = parameters.getText("toolbar") # toolbar dictionnary
        file = toolbarT["file"]
        settings = toolbarT["settings"]
        languages = toolbarT["languages"]
        # Main menu on the toolbar
        toolbar = Menu(self.w)
        self.w.config(menu=toolbar)
        # File menu:
        fileMenu = Menu(toolbar, tearoff=0) 
        # Different buttons on the menu
        toolbar.add_cascade(label=file["name"], menu=fileMenu)
        fileMenu.add_command(label=file["home"], command=self.home)
        fileMenu.add_command(label=file["minimize"], command=lambda:self.resize(False))
        fileMenu.add_command(label=file["maximize"], command=self.resize)
        fileMenu.add_command(label=file["print"], command=self.print)
        fileMenu.add_command(label=file["quit"], command=self.w.quit)        
        # Settings menu
        settingsMenu = Menu(toolbar, tearoff=0) # (Menu) parMenu : parameters menu
        toolbar.add_cascade(label=settings["name"], menu=settingsMenu)
        # Sub Menu: themes
        themesMenu = Menu(settingsMenu, tearoff=0)
        settingsMenu.add_cascade(label=settings["themes"], menu=themesMenu)
        themesMenu.add_command(label=settings["dark"], command=lambda:self.setTheme("dark"))
        themesMenu.add_command(label=settings["light"], command=lambda:self.setTheme("light"))
        # Sub Menu: languages
        self.languagesM = Menu(settingsMenu, tearoff=0)
        settingsMenu.add_cascade(label=languages["name"], menu=self.languagesM)
        self.languagesM.add_command(label=languages["en"], command=lambda:self.setLang("en"))
        self.languagesM.add_command(label=languages["fr"], command=lambda:self.setLang("fr"))
        self.languagesM.add_command(label=languages["de"], command=lambda:self.setLang("de"))

    def invalidFile(self):
        """Displays an error message because no file has been selected."""
        # Attention: size of toolbar = 24px
        h = self.w.winfo_height() # height of the screen
        hnf = int(3/106*h) + 2*int(1/53*h) + 24 # height text + 2*pady of noFile + toolbar size
        if h > self.homeFrame.winfo_height() + hnf:
            noFile = Label(self.homeFrame, text=parameters.getHomeT("home")["error"], fg="red", font=("Arial", int(3/106*h), "bold"),
                        bg=parameters.getGroundColor("bg")) # information for the user
            noFile.pack(pady=int(1/53*h)) # displays the message
            self.w.after(2000, noFile.destroy) # destroys the message after it has been displayed
    
    def resize(self, fs=True):
        """Resize the window in full screen by default. True: maximize window, False: minimize window
        
        Parameter:
            - (bool) fs: fullscreen
        """
        # TODO Updates sizes of Labels, buttons and images
        self.w.attributes("-fullscreen", fs)

    def resizeImgs(self):
        """Resize all images proportionally to the screen size."""
        f = "program/decoration/images/" # images folder
        b = "program/decoration/buttons/" # buttons folder
        flgs = (f+"uk_flag.png", f+"us_flag.png", f+"fr_flag.png", f+"de_flag.png") # flags list
        langBtts = (b+"generate/de.png", b+"generate/en.png", b+"generate/fr.png", b+"check/de.png", b+"check/en.png", b+"check/fr.png")
        # Other buttons (reload and close)
        Image.open(b+"close.png").resize((int(2/53*self.w.winfo_height()), int(2/53*self.w.winfo_height()))).save(b+"close.png") # square
        Image.open(b+"reload.png").resize((int(24/265*self.w.winfo_height()), int(24/265*self.w.winfo_height()))).save(b+"reload.png") # square
        for flag in flgs: # Resize flags
                img = Image.open(flag)
                img.resize((int(55/384*self.w.winfo_width()), int(183/1060*self.w.winfo_height())))
                img.save(flag)
        for btt in langBtts: # Resize languages buttons
            img = Image.open(btt)
            img.resize((img.width, int(93/1060*self.w.winfo_height())))
            img.save(btt)

    def print(self):
        """Asks the user if he wants to print the page. Prints the page containing a vocabulary list.
        
        Method:
            If the user wants to print his vocabulary list
                Takes a screenshot
                Starts the process of printing the screenshot        
        """
        print = parameters.getText("print")
        if self.w.attributes("-fullscreen") == False: # Checks if the screen is not displayed in fullscreen
            return messagebox.showwarning(print["section"], print["warn"]) # warn user: not in full screen
        # Asks if the user wants to print his exercise
        if messagebox.askquestion(print["section"], print["question"], icon="question") == "yes":
            n = str(len(listdir("./printable_files/"))) # (str) n : number of files in (directory) printable_files 
            file = "./printable_files/printable" + n
            sleep(2) # waits 2 seconds
            h = self.w.winfo_height()
            try:
                # screenshot args: (y start, x start, width, height)
                if self.section.winfo_width() <= self.title.winfo_width():
                    screenshot(
                        region=(
                            self.w.winfo_width()/2 - self.title.winfo_width()/2, int(5/212*h),
                            self.title.winfo_width(), self.title.winfo_height() + self.section.winfo_height() + 2*int(5/212*h)
                        )
                    ).save(file + ".png")
                else:
                    screenshot(
                        region=(
                            self.w.winfo_width()/2 - self.section.winfo_width()/2, int(5/212*h),
                            self.section.winfo_width(), self.title.winfo_height() + self.section.winfo_height() + 2*int(5/212*h)
                        )
                    ).save(file + ".png")                
                Image.open(file + ".png").convert("RGB").save(file + ".pdf") # converts the .png into .pdf
                remove(file + ".png") # deletes the screenshot but keep the pdf version
                try:
                    startfile(file + ".pdf", "print") # starts the process to print the pdf
                except:
                    messagebox.showinfo(print["section"], print["infoSof1"] + print["infoSof2"]) # Inform user: no default pdf reader
            except:
                # Executes this code if the user is not on a translation page
                messagebox.showinfo(print["section"], print["infoUser"]) # Inform the user: no vocabulary to print

    def getAnswers(self, frame):
        """Returns the list of the user's answers"""
        self.answers = [] # attribute which content the user"s anwsers
        for w in frame.winfo_children(): # browses the widgets of the frame
            if w.winfo_class() == "Entry": # checks if the widget is an entry
               self.answers.append(w.get()) # adds it if it's the case
        return self.answers
